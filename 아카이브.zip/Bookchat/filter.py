def Shortword(value):
    return value[:50]

def Replacebar(value):
    temp = value.replace('|',' ')
    return temp